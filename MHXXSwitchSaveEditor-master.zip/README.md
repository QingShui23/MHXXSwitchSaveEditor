# MHXXSwitchSaveEditor
A save editor for Monster Hunter XX Switch and 3DS versions
FIRST VERSION
NOT TESTED THOROUGHLY ALWAYS MAKE A BACK UP
THIS CAN AND PROBABLY WILL RUIN YOUR SAVE

USAGE:
1. Extract MHXX save file with your save manager (switch tested with Checkpoint)
2. Open the system file with this editor
3. Edit all you want.
4. Save the system file.
5. Place both the edited system file and the system_backup back on the sd card of your switch
6. Import the saves with your save manager

CONVERTING: 
1. Start by loading the 3DS save file
2. In the convert menu select "To Switch"
3. Select your extracted switch save file (just an empty one, needs to be created by your switch)
4. Save the file and import it on the switch

I do not know if it is important but to be sure but do not change the name of the saves, keep them system and system_backup

Based off: https://github.com/mineminemine/MHXXSaveEditor/
